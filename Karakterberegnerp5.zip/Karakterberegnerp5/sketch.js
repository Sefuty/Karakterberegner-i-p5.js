let subjects = [];
let result;

function setup() {
  createCanvas(1200, 600);
  background('lightgray');

  addSubject("Matematik");
  addSubject("Dansk");
  addSubject("Biologi");
  addSubject("Engelsk");

  createButton('Beregn Gennemsnit').position(width - 200, height - 50).mousePressed(beregnGns);

  result = createP('').position(width - 200, height - 100);
}

function addSubject(subjectName) {
  let container = createDiv().class('subject-container-small');
  container.position(200, 200 + subjects.length * 80);
  

  let heading = createP(subjectName).class('subject-heading').position(10, 0);
  let input = createInput('').attribute('placeholder', 'Indtast karakter').position(120, 0);
  let button = createButton(`Beregn ${subjectName}`).mousePressed(() => beregnGns(subjectName)).position(230, 0);

  container.child(heading).child(input).child(button).parent(document.body);

  subjects.push({ name: subjectName, input, button });
}

function beregnGns() {
  let sum = subjects.reduce((acc, subject) => acc + float(subject.input.value()), 0);
  let gennemsnit = sum / subjects.length;
  result.html(`Gennemsnit: ${gennemsnit.toFixed(2)}`);
}